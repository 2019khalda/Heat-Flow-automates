import sys
sys.path.append("c:/Users/rapha/Desktop/Coding Weeks/2nd project/heat_flow/heatflow") 

from heatflow.conducto import *
from heatflow.main import *


def test_conducto_convection():
    a=np.array([[0,1,0.1,0.4],[a_air,a_air,0,0.1],[0.1,2,1.2,a_air],[0.7,0.5,a_air,a_air]])

    test_equality = np.array(conducto_convection(a) == np.array([[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]],
    [[0,0,0,0],[0,0,0,0],[0,h_air,0,0],[0,0,0,0]],
    [[0,0,0,0],[h_air,0,0,0],[0,0,h_air,h_air],[0,0,0,0]],
    [[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]]]))

    assert test_equality.all()


def test_source():
    grid = np.zeros((4,4))
    source(1, 2, 100, grid)
    test_equality = np.array(grid == np.array([[0,0,0,0],[0,0,100,0],[0,0,0,0],[0,0,0,0]]))
    
    assert test_equality.all()

def test_createChamber():
    test_equality = np.array(createChamber(25,4,4) == np.array([[25,25,25,25],[25,25,25,25],[25,25,25,25],[25,25,25,25]]))
    
    assert test_equality.all()


