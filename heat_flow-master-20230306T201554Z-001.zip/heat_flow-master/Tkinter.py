from tkinter import *
import numpy as np
from matplotlib.colors import to_hex
from matplotlib import cm
from pylab import *
import matplotlib.animation as animation

#dictionnaires
hcc= 15    #pour l'air hcc est le meme pr tous les matériaux

#conductivité thermique lambda
dict_lambda={"air":0.02,
"bois":0.16,
"polyestère":0.03,
"coton":0.05,
"verre":1.2,
"fer":80,
"béton":0.9,
"plastique":0.7,
"carton":0.11}

#dictionnaire des produit capacité thermique * masse volumique
dict_capacité={"air":1200,
"bois":1000000,
"polyestère":1500,
"coton":8000,
"verre":1800000,
"fer":3500,
"béton":1300000,
"plastique":300000,
"carton":84000} 


echelle = 100   #echelle de température



def damier(): #fonction dessinant le tableau
    ligne_vert()
    ligne_hor()
        
def ligne_vert():
    c_x = 0
    while c_x != width:
        can1.create_line(c_x,0,c_x,height,width=1,fill='black')
        c_x+=c
        
def ligne_hor():
    c_y = 0
    while c_y != height:
        can1.create_line(0,c_y,width,c_y,width=1,fill='black')
        c_y+=c

def click_gauche(event): #fonction rendant vivante la cellule cliquée donc met la valeur 1 pour la cellule cliquée au dico_case
    x = (event.x -(event.x%c))//c
    y = (event.y -(event.y%c))//c
    global x1,y1,etat,mat,temp,source
    if mode == "point" : #on est en train de définir des points
        if var_case_temp.get() == 1 :
            temp[x,y]=temperature
            can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, fill=color,outline = couleur_contour[mat[x,y]],width = epaisseur,tags = (x,y))
        if var_case_mat.get() == 1:
            mat[x,y]=materiau
            can1.create_rectangle(x*c, y*c, x*c+c, y*c+c,outline = contour,width = epaisseur,tags = (x,y))
        if var_source.get()==1:
            source[x,y]=1
        if var_source.get() == 0:
            source[x,y]=0
    elif mode == "ligne" : #on est en train de définir des lignes 
        if etat == 0 : #c'est le premier point
            x1,y1 = x,y
            can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, fill="yellow",tags = (x,y))
            etat = 1
        else : # c'est le deuxième point sélectionné
            etat = 0
            if x1<x:
                x2,y2 = x,y
            else:
                x2,y2 = x1,y1
                x1,y1 = x,y
            if x1!=x2:
                a = (y2-y1)/(x2-x1)
                b = y2 - a*x2 + ((c/2))/c
                for i in range(x1,x2):
                    y_un = int(a*i+b)
                    y_deux = int(a*(i+1)+b)
                    for y in range(min(y_un,y_deux),max(y_un,y_deux)+1):
                        if var_case_temp.get() == 1 :
                            x = i
                            temp[x,y]=temperature
                            can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, fill = color, outline = couleur_contour[mat[x,y]],width = epaisseur,tags = (x,y))
                        if var_case_mat.get() == 1:
                            x = i
                            mat[x,y]=materiau
                            can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, outline = contour,width = epaisseur,tags = (x,y))
                        if var_source.get()==1:
                            source[x,y]=1
                        if var_source.get() == 0:
                            source[x,y]=0
                if var_case_temp.get() == 1 :
                    temp[x2,y2]=temperature
                    can1.create_rectangle(x2*c, y2*c, x2*c+c, y2*c+c, fill = color, outline = couleur_contour[mat[x,y]],width = epaisseur,tags = (x2,y2))
                if var_case_mat.get() == 1:
                    mat[x2,y2]=materiau
                    can1.create_rectangle(x2*c, y2*c, x2*c+c, y2*c+c, outline = contour,width = epaisseur,tags = (x2,y2))
                if var_source.get()==1:
                    source[x,y]=1
                if var_source.get() == 0:
                    source[x,y]=0
            else :   #on dessine un ligne verticale
                x = x1
                for y in range(min(y1,y2), max(y1,y2)+1):
                    if var_case_temp.get() == 1 :
                        temp[x,y]=temperature
                        can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, fill = color, outline = couleur_contour[mat[x,y]],width = epaisseur,tags = (x,y))
                    if var_case_mat.get() == 1 :
                        mat[x,y]=materiau
                        can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, outline = contour,width = epaisseur,tags = (x,y))
                    if var_source.get()==1:
                        source[x,y]=1
                    if var_source.get() == 0:
                        source[x,y]=0

    else:    #on est en train de définir des rectangles
        if etat == 0 : #c'est le premier point
            x1,y1 = x,y
            can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, fill="yellow",tags = (x,y))
            etat = 1
        else : # c'est le deuxième point sélectionné
            etat = 0
            if x1<x:
                x2,y2 = x,y
            elif x1>x:
                x2,y2 = x1,y1
                x1,y1 = x,y
            for x in range(x1,x2+1):
                for y in range(min(y1,y2),max(y1,y2)+1):
                    if var_case_temp.get() == 1 :
                        temp[x,y]=temperature
                        can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, fill = color, outline = couleur_contour[mat[x,y]],width = epaisseur,tags = (x,y))
                    if var_case_mat.get() == 1 :
                        mat[x,y]=materiau
                        can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, outline = contour,width = epaisseur,tags = (x,y))
                    if var_source.get()==1:
                        source[x,y]=1
                    if var_source.get() == 0:
                        source[x,y]=0


def change_vit(event): #fonction pour changer la vitesse(l'attente entre chaque étape)
    global vitesse
    vitesse = int(eval(entree_vitesse.get()))
    print(vitesse)

def update(frameNum, img, a,sources):
    global grid,new_grid
    new_grid = np.copy(grid)
    lenght,width = np.shape(grid)
    #h= conducto_convection(a)
    for i in range(1,lenght-1): 
        for j in range(1,width-1): 
            conduction = a[i][j]* ( grid[i+1][j]+grid[i][j+1]-4*grid[i][j]+grid[i-1][j]+grid[i][j-1] )
            #convection = h[i][j][0]/(r*c)*(grid[i,j]-grid[i-1,j])+h[i][j][2]/(r*c)*(grid[i,j]-grid[i+1,j])+h[i][j][3]/(r*c)*(grid[i,j]-grid[i,j+1])+h[i][j][1]/(r*c)*(grid[i,j]-grid[i,j-1]) # discrete fourier heat equation + conducto_convection
            new_grid[i][j]=grid[i][j]+conduction
    for s in sources:
        (x,y,temperature_source) = s
        new_grid[x,y] = temperature_source
    #update data
    img.set_data(new_grid)
    grid = np.copy(new_grid)
    return img


def go(event):
    global grid,new_grid
    save = var_save.get()
    if save == 1:
        save = True
    else :
        save = False
    liste_sources = []
    a = np.zeros((l,h))
    for x in range(l):
        for y in range(h):
            val_materiau=tous_les_materiaux[mat[x,y]]
            val_lambda = dict_lambda[val_materiau]
            val_capa = dict_capacité[val_materiau]
            a[x,y]=(delta_t * val_lambda*(10**3)) / (val_capa * delta_x * delta_x)
            if source[x,y]==1:
                liste_sources.append((x,y,temp[x,y]))
    grid = np.copy(temp)
    # set up animation 
    fig, ax = subplots() 
    img = ax.imshow(grid, interpolation='nearest', cmap=cm.get_cmap('jet'), vmin=0, vmax=100)

    ani = animation.FuncAnimation(fig, update, fargs=(img, a,liste_sources), 
								frames = n_generations, 
								interval=vitesse, 
								save_count=50, repeat = False) 
    
	# set output file
    if save :
        ani.save("save.gif",writer= "avhbak",fps=30)   # extra_args=['-vcodec', 'libx264'])
    cbar_ax = fig.add_axes([0.85, 0.15, 0.03, 0.7])
    cbar_ax.set_xlabel('$T$ (°K)', labelpad=20)
    fig.colorbar(img, cax=cbar_ax)
    show() 
    







def selection_mat(event):
    global materiau,contour
    selection = liste_mat.curselection()
    if len(selection) == 1 :
        materiau = int(liste_mat.curselection()[0])
        contour = couleur_contour[materiau]
        print("le matériau séléctionné est "+tous_les_materiaux[materiau])

def selection_style(event):
    global mode
    selection = style_dessin.curselection()
    if len(selection) == 1 :
        mode = liste_modes[style_dessin.curselection()[0]]
        print("le mode de dessin séléctionné est "+mode)

def change_temp(event):
    global temperature,color
    temperature = int(entree_temp.get())
    print("la température séléctionnée est : "+str(temperature)+"°C")
    color = to_hex(cmap(round(156+((temperature*100)/echelle))))


def completer(event):
    for x in range(l):
        for y in range(h):
            if temp[x,y] == 0:
                can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, fill = "white", outline = "white",width = epaisseur,tags = (x,y))
            if mat[x,y] == 0:
                can1.create_rectangle(x*c, y*c, x*c+c, y*c+c, outline = "white",width = epaisseur,tags = (x,y))

def change_generation(event):
    global n_generations 
    n_generations = entree_generation.get()

def change_delta_x(event):
    global delta_x
    delta_x = entree_delta_x.get()

def change_delta_t(event):
    global delta_t
    delta_t = entree_delta_t.get()

def change_echelle(event):
    global echelle 
    echelle = int(entree_echelle.get())



fen1 = Tk()

hauteur = Entry(fen1)    #choisir le nombre de cellules en hauteur
largeur = Entry(fen1)    #choisir le nombre de cellules en largeur

hauteur.grid(row = 0, column = 1)
largeur.grid(row = 1, column = 1)

hauteur_txt = Label(fen1)
largeur_txt = Label(fen1)

hauteur_txt.configure(text = "entrer le nombre de cellules en hauteur")
largeur_txt.configure(text = "entrer le nombre de cellules en largeur")

hauteur_txt.grid(row=0,column = 0)
largeur_txt.grid(row=1 , column = 0)

#choix de la vitesse de l'animation
chaine_vitesse = Label(fen1)
chaine_vitesse.configure(text = "Attente entre chaque étape (ms) :")
chaine_vitesse.grid(row = 2,column =0)
entree_vitesse = Entry(fen1)
entree_vitesse.bind("<Return>", change_vit)
entree_vitesse.grid(row = 2,column =1)

#choix du nombre de générations
chaine_generation = Label(fen1)
chaine_generation.configure(text = "Nombre d'itérations : ")
chaine_generation.grid(row = 3,column =0)
entree_generation = Entry(fen1)
entree_generation.bind("<Return>", change_generation)
entree_generation.grid(row = 3,column =1)

#choix de la discrétisation spaciale
chaine_delta_x = Label(fen1)
chaine_delta_x.configure(text = "Discrétisation spaciale (en m): ")
chaine_delta_x.grid(row = 4,column =0)
entree_delta_x = Entry(fen1)
entree_delta_x.bind("<Return>", change_delta_x)
entree_delta_x.grid(row = 4,column =1)

#choix de la discrétisation temporelle
chaine_delta_t = Label(fen1)
chaine_delta_t.configure(text = "Discrétisation temporelle (en s): ")
chaine_delta_t.grid(row = 5,column =0)
entree_delta_t = Entry(fen1)
entree_delta_t.bind("<Return>", change_delta_t)
entree_delta_t.grid(row = 5,column =1)

#choix de l'échelle
chaine_echelle = Label(fen1)
chaine_echelle.configure(text = "choix de l'échelle de température: ")
chaine_echelle.grid(row = 6,column =0)
entree_echelle = Entry(fen1)
entree_echelle.bind("<Return>", change_echelle)
entree_echelle.grid(row = 6,column =1)





h=50    #nombre de cellules en hauteur
l=50    #nombre de cellules en largeur


def change_hauteur(event): #fonction pour changer la vitesse(l'attente entre chaque étape)
    global h
    h = int(eval(hauteur.get()))
    print("nombre de cellules en hauteur = "+str(h))

def change_largeur(event): #fonction pour changer la vitesse(l'attente entre chaque étape)
    global l
    l = int(eval(largeur.get()))
    print("nombre de cellules en largeur = "+str(l))

hauteur.bind("<Return>", change_hauteur)
largeur.bind("<Return>", change_largeur)

fen1.mainloop()

c = min(int(800/h),int(1800/l))    #taille de chaque cellule en pixels
height = h*c     #taille de la fenêtre en hauteur, en nombre de pixels
width = l*c      #taille de la fenêtre en largeur, en nombre de pixels


#initialisations
vitesse=1
mat = np.zeros((l,h),dtype = int)
temp = np.zeros((l,h), dtype = float)
materiau = 0
temperature = 27
mode = "ligne"      #correspond à la manière de dessiner
color = "black"     #correspond à la couleur dans laquelle on va colorer la case
x1,y1 = 0,0         #défini les coordonnées du premier point séléctionné pour les lignes ou les rectangles
etat = 0            #on n'a pas encore cliqué sur la première case
tous_les_materiaux = ["air","bois","polyestère","coton","verre","fer","béton","plastique","carton"] #tous les matériaux disponibles 
couleur_contour = ["#ffffff","#8b5a2b","#2bfafa","#A9A9A9","#778899","#7B9095","#5a3a22","#791cf8","#5b3c11"]
liste_modes = ["point","ligne","rectangle"]
contour = "white"
epaisseur = c/3
n_generations = 1000
source = np.zeros((l,h),dtype = int)
delta_x = 1
delta_t = 1
cmap = get_cmap('jet')
grid = np.copy(temp)
new_grid = np.copy(temp)




#programme "principal" 
fen2 = Tk()

can1 = Canvas(fen2, width =width, height =height, bg ='white')
can1.bind("<Button-1>", click_gauche)
can1.pack(side = TOP)

damier()

bouton1 = Label(fen2, text = "GO!")
bouton1.pack(side = TOP)
bouton1.bind("<Button-1>", go)

bouton2 = Label(fen2, text = "compléter automatiquement")
bouton2.pack(side = TOP)
bouton2.bind("<Button-1>", completer)


#choisir le materiau
liste_mat = Listbox(fen2)
liste_mat.pack(side = LEFT)
liste_mat.insert(END, "air")
liste_mat.insert(END, "bois")
liste_mat.insert(END, "polyestère")
liste_mat.insert(END, "coton")
liste_mat.insert(END, "verre")
liste_mat.insert(END, "fer")
liste_mat.insert(END, "béton")
liste_mat.insert(END, "plastique")
liste_mat.insert(END, "carton")
liste_mat.bind("<Button-1>", selection_mat)

#choisir le style de dessin
style_dessin = Listbox(fen2)
style_dessin.pack(side = LEFT)
style_dessin.insert(END, "point")
style_dessin.insert(END, "ligne")
style_dessin.insert(END, "rectangle")
style_dessin.bind("<Button-1>",selection_style)

#choix de la température
chaine_temp = Label(fen2)
chaine_temp.configure(text = "Selection de la température : ")
chaine_temp.pack(side = LEFT,fill = X)
entree_temp = Entry(fen2)
entree_temp.bind("<Return>", change_temp)
entree_temp.pack(side = LEFT,fill = X)





#bouton à cocher pour choisir si on modifie le materiau ou la température
var_case_temp = IntVar()
case_temp = Checkbutton(fen2, text="modifier la température", variable=var_case_temp)
case_temp.pack(side = TOP,fill = X)

var_case_mat = IntVar()
case_mat = Checkbutton(fen2, text="modifier le matériau", variable=var_case_mat)
case_mat.pack(side = TOP,fill = X)

var_save = IntVar()
case_save = Checkbutton(fen2, text = "save", variable = var_save)
case_save.pack(side = TOP,fill = X)

var_source = IntVar()
case_source = Checkbutton(fen2, text = "source", variable = var_source)
case_source.pack(side = TOP,fill = X)

fen2.mainloop()






