from main import *
a_air=2*10**(-5)
h_air=1000

def conducto_convection(a):
    lenght=a.shape[0]
    width=a.shape[1]
    h=np.array([[[0,0,0,0]for i in range (lenght)]for j in range (width)])
    for i in range (1,lenght-1):
        for j in range (1,width-1):
            if a[i,j]==a_air:
                h[i][j]=[0,0,0,0]
            else:
                h[i][j]=[0,0,0,0]
                if a[i-1][j]==a_air:
                    h[i][j][0]=h_air
                if a[i+1][j]==a_air:
                    h[i][j][2]=h_air
                if a[i][j-1]==a_air:
                    h[i][j][1]=h_air
                if a[i][j+1]==a_air:
                    h[i][j][3]=h_air
    return h

