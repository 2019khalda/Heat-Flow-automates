Le programme simule la diffusion de la chaleur à partir de l'équation de la chaleur
La simulation est efficace dans les solides ou les assemblages de matériaux quasiment uniquement solides comme les matériaux composites.

Commande pour lancer la simulation : python main.py --interval=* --n_generations=*, l'utilisateur pourra remplacer les "*" par les valeurs qu'il choisit. Si celui-ci n'indique rien alors la simulation s'executera avec les valeurs par defaut.


-interval(int), default = 1 'interval entre chaque image en ms'
-n_generations(int), default = 1000 'nombre de générations'

Il est possible de lancer la simulation avec une interface graphique, dans laquelle l'utilisateur peut choisir le paramétrage, la disposition des matériaux, de la température innitiales ainsi que les sources.

Afin de lancer celui-ci il faut utiliser la commande: "python Tkinter.py"