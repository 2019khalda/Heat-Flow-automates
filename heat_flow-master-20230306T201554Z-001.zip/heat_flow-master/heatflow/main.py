import argparse
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from conducto import *

a_fer=0.23


# create a ixj room with an uniform temperature
def createChamber(temp, width, lenght):
	grid=np.zeros((lenght,width))
	for i in range (lenght):
		for j in range (width):
			grid[i][j]=temp
	return grid


# create a source
def source(x, y, temp, grid):
	grid[x][y] = temp


# apply the heat equation to the grid
def update(frameNum, img, grid):

	newGrid = grid.copy()
	lenght = grid.shape[0]
	width = grid.shape[1]

	
	a = a_fer


	for i in range(1,lenght-1): 
		for j in range(1,width-1): 
			newGrid[i][j]=a*(grid[i+1][j]+grid[i][j+1]-4*grid[i][j]+grid[i-1][j]+grid[i][j-1])+grid[i][j]# discrete fourier heat equation
			source( 30, 30, 1000, newGrid)
			source( 1, 58, 1000, newGrid)
			source( 58, 1, 1000, newGrid)
			source( 1, 1, 1000, newGrid)
			source( 58, 58, 1000, newGrid)




	# update data
	img.set_data(newGrid)
	grid[:] = newGrid[:]
	return img


# main() function 
def main(): 
	# parse arguments 
	parser = argparse.ArgumentParser(description="Runs simulation.")

	# add arguments 
	parser.add_argument('--lenght', dest='lenght', default=60)
	parser.add_argument('--width', dest='width', default=60)
	parser.add_argument('--mov-file', dest='movfile', default=False)
	parser.add_argument('--interval', dest='interval', default=100)
	parser.add_argument('--n_generations', dest='n_generations', default = 1000)
	args = parser.parse_args() 
	
	# set parameters 
	n_generations = int(args.n_generations)
	interval = int(args.interval)

	# declare grid 
	grid = createChamber(22,60, 60)

	# set up animation 
	fig, ax = plt.subplots() 
	img = ax.imshow(grid, interpolation='nearest', cmap=plt.cm.jet, vmin=22, vmax=100)

	ani = animation.FuncAnimation(fig, update, fargs=(img, grid), 
								frames = n_generations, 
								interval=interval, 
								save_count=50, repeat = False) 

	# set output file
	if args.movfile == True:
		if args.movfile: 
			ani.save(args.movfile, fps=30, extra_args=['-vcodec', 'libx264'])
	
	cbar_ax = fig.add_axes([0.85, 0.15, 0.03, 0.7])
	cbar_ax.set_xlabel('$T$ (°K)', labelpad=20)
	fig.colorbar(img, cax=cbar_ax)
	plt.show() 

#call main 
if __name__ == '__main__':
	main() 

